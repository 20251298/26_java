package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// 1. 기본 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		//2. 변수 초기화
		isTrue = false;
		age = 21;
		height = 162.5;
		weight = 100.5;
		
		
		
		//2. 레퍼런스형 - 3개 (배열, 클래스, 인터페이스
		String name="고승연";
		String address="광명";
		
		//name = "고승연";
		String s = new String("고승연");
		
		DataTypeTest dtt = new DataTypeTest();
				
		//3. 변수 값 출력하기
		
		System.out.println(isTrue);
		System.out.println("나이:"+age);
		System.out.println("키:"+height);
		System.out.println("몸무게:"+weight);
		System.out.println("이름:"+name);
		System.out.println("주소:"+address);
	}

}
