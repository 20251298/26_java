package day02;

public class hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("주식 분석 프로그램 만들기");
	}

}
