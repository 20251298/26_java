package day03;
import java.util.Scanner;
public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		System.out.println("시간을 점수로 입력하세요: ");
		int time = scan.nextInt();
		int second = time % 60;//60으로 나눈 몫
		int minute = (time / 60) % 60;//time을 60으로 나누고, 나머지를 다시 60으로 나눈 몫
		int hour = (time / 60); //time으로 60으로 나눈 몫
		
		System.out.println(time + "은" + hour + "시" + minute +"분" + second + "초");
	}

}
