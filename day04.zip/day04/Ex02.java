package day04;
import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in);
		System.out.println("필기시험 점수를 입력하시오: ");
		int test1 = scn.nextInt();
		
		System.out.println("토익 점수를 입력하시오: ");
		int test2 = scn.nextInt();
		
		if(test1>=80 && test2>=850) {
			System.out.println("합격");
		}else {
			System.out.println("불합격");
		}
		
		
			

	}

}
