package day04;
import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int balance = 10000; //교통카드 잔액
		System.out.println("나이를 입력하시오: ");
		
		int age = scanner.nextInt(); //정수 입력
		
		if(age>=19) {
			balance -= 1200;
			System.out.println("일반: "+ balance);
		}else if(age>=13){
			balance -= 720;
			System.out.println("중고등학생: "+ balance);
		}else if(age>=7){
			balance -= 450;
			System.out.println("초등학생: "+ balance);
		}
		

	}

}
