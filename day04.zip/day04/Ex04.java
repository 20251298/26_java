package day04;
import java.util.Scanner;
public class Ex04 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("가위바위보 중에 하나를 고르시오: ");
		String user1 = scanner.next();
		System.out.println("철수 >>>" + user1);
		String user2 = scanner.next();
		System.out.println("영희 >>>" + user2);
		
		// 철수가 승리할 모든 경우
		if(user1.equals("가위")) { // 철수가 가위일 경우
			if(user2.equals("가위")) {
				System.out.println("비겼습니다.");
			}else if(user2.equals("보")) {
				System.out.println("철수가 이겼습니다.");
			}else if(user2.equals("바위")) {
				System.out.println("철수가 졌습니다.");
			}else {
				System.out.println("잘못 입력했습니다.");
			}
		}else if(user1.equals("바위")) { // 철수가 바위일 경우
			if(user2.equals("바위")) {
				System.out.println("비겼습니다.");
			}else if(user2.equals("가위")) {
				System.out.println("철수가 이겼습니다.");
			}else if(user2.equals("보")) {
				System.out.println("철수가 졌습니다.");
			}else {
				System.out.println("잘못 입력했습니다.");
			}
		}else if(user1.equals("보")) { // 철수가 보일 경우
			if(user2.equals("보")) {
				System.out.println("비겼습니다.");
			}else if(user2.equals("바위")) {
				System.out.println("철수가 이겼습니다.");
			}else if(user2.equals("가위")) {
				System.out.println("철수가 졌습니다.");
			}else {
				System.out.println("잘못 입력했습니다.");
			}
		}else {
			System.out.println("잘못 입력했습니다.");
		}
		
		scanner.close();
	}
}