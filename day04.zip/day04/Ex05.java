package day04;

public class Ex05 {

   public static void main(String[] args) {

      // 1부터 100까지의 합을 계산하는 for 반복문
      int sum = 0;

      for(int i = 1; i <= 100; i++) {
         sum = sum + i;
         // System.out.print(i);
      }

      System.out.println(sum);
   }
}