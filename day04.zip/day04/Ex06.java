package day04;

public class Ex06 {

	public static void main(String[] args) {
		//1부터 10까지의 합을 계산하는 while 반복문 완성
		 //for(초기식;조건식;증감식){실행문}
		
		int i = 1;
		int sum = 0;
		while(i<=100) {
			sum = sum+i;
			i++;
		}

	}

}
