package day04;

import java.util.Scanner;

public class Ex07 {

   public static void main(String[] args) {

      int count = 0; // 입력 개수
      int sum = 0;   // 합

      Scanner scanner = new Scanner(System.in);

      System.out.println("정수를 입력하고 마지막에 -1을 입력하세요.");

      int n = scanner.nextInt(); // 첫 입력

      while(n != -1) { // -1 나오면 종료
         sum += n;
         count++;
         n = scanner.nextInt(); // 다음 입력
      }

      if(count == 0) {
         System.out.println("입력된 수가 없습니다.");
      } else {
         System.out.print("정수의 개수는 " + count + "개이며 ");
         System.out.println("평균은 " + (double)sum / count + "입니다.");
      }

      scanner.close();
   }
}