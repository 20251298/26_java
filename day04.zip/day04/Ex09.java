package day04;

import java.util.Scanner;

public class Ex09 {

   public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);

      int sum = 0; // 합계 변수 선언

      for(int i = 1; i <= 5; i++) {
         System.out.println("정수를 입력하세요");
         int num = scan.nextInt();

         // 만약 정수가 음수라면 무시, 양수이면 합 추가
         if(num < 0)
            continue;
         else {
            sum = sum + num;
         }
      }

      System.out.println("양수의 합은: " + sum);
      scan.close();
   }
}