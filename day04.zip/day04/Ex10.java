package day04;

import java.util.Scanner;

public class Ex10 {

   public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);

      int sum = 0;
      System.out.println("정수를 입력하세요");

      while(true) {
         int num = scan.nextInt();

         if(num <= 0) {
            break;
         } else {
            sum = sum + num;
         }
      }

      System.out.println("합은: " + sum);
      scan.close();
   }
}