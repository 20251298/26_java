package day05;
import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
	int intArray[] = new int[5];
	int sum=0;
	
	System.out.println("양수 5개를 입력하세요: ");
	for(int i=0;i<5;i++) {
		intArray[i]=scanner.nextInt();
		sum += intArray[i];
		}
	int average = sum /5;
	System.out.println("합계은" + sum + "입니다,");
	System.out.println("평균은" + average + "입니다");
		
		scanner.close();
	}

}
