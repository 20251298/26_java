package day07;

public class PersonTest {

	public static void main(String[] args) {
		// Person 객체 생성하기
		Person hong = new Person(); //디폴트 생성자 함수
//		hong.name = "홍길동";
//		hong.age = 20;
//		hong.abc = 'A';
		hong.밥먹기();
		hong.운동하기("헬스");
		
		Person kang = new Person();
//		kang.name = "강지후";
//		kang.age = 21;
//		kang.abc = 'B';
		kang.밥먹기();
		kang.운동하기("숨쉬기");
		
		//hong.addr = "대전 동구 용운동"
		
		System.out.println(hong.getName()); //static 메소드호출은 클래스 이름으로 사용가능
	}

}
