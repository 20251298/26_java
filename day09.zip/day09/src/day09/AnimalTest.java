package day09;

public class AnimalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal cat = new Animal();
		Human hong = new Human();
		
		hong.setName("홍길동");
		
		
		//cat name = "뽀삐"; 불가능
		cat.setName("뽀삐");
		cat.setAge(10);
		hong.setAge(20);
		
		System.out.println(cat.getAge());
		System.out.println(hong.getName());
		System.out.println(hong.getAge());
	}

}
