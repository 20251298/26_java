package day09;

import java.util.Scanner;
public class Grade {
String name;
int java,web,os;

	public Grade(String name, int a, int b, int c) {
		this.name=name;
		this.java = a;
		this.web=b;
		this.os = c;
	}


	public Grade(String name){
	this.name = name;
}
	

	public Grade(int a, int b, int c) {
	java = a;
	web = b;
	os = c;
}
	
	public String getName() {
		return name;
	}
	
	public int getAverage() {
		int sum = (java+web+os)/3;
		return sum;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("이름, 자바, 웹프로그래밍, 운영체제 순으로 점수 입력>>");
		String name = scanner.next();
		int java = scanner.nextInt();
		int web = scanner.nextInt();
		int os = scanner.nextInt();
		Grade st = new Grade(name,java,web,os);
		System.out.println(st.getName() + "의 평균은" + st.getAverage());
	}

}
