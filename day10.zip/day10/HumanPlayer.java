package day10;
import java.util.Scanner;
public class HumanPlayer extends Player {
	private Scanner scanner = new Scanner(System.in);
	public HumanPlayer(String name) {
		super(name);
	}
	@Override
	public String turn() {
		System.out.println(getName() + "님 뭘 내시겠습니까?");
		return scanner.next();
	}
	}

