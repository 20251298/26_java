package day10;

public class SchoolApp {

	public static void print(Person P) {
//		if(P instanceof Person) {
//			System.out.println("사람객체입니다");
//		}
		if(P instanceof Student) {
			System.out.println("학생객체입니다");
		}
		if(P instanceof Researcher) {
			System.out.println("리서처객체입니다");
		}
		
	}
	
	
	public static void main(String[] args) {
		
		// 업캐스팅
		Person p = new Person ("이사람","0110");
		Person p1 = new Student("김학생", "1111");
		Person p2 = new Researcher("박리서처", "2222");
		
		print(p1);
	}

}
