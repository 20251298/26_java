package day11;

public class SamsungPhone implements PhoneInterface {

   public static void main(StringEx[] args) {
      SamsungPhone sp = new SamsungPhone();
      sp.sendCall();
      sp.receiveCall(); 
      System.out.println(sp.toString());
      PhoneInterface pi = new SamsungPhone();
   }
   
@Override
	public String toString() {
	
		return "스마트폰입니다";
	}
   

public void sendCall() {
   System.out.println("띠리리리링");
}


public void receiveCall() {
   System.out.println("전화받아요");
   
}

}
