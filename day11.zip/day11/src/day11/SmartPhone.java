package day11;

public class SmartPhone extends Calc implements PhoneInterface{

	public static void main(StringEx[] args) {
		SmartPhone sp = new SmartPhone();
		sp.sendCall();
		sp.receiveCall();
		System.out.println("3+5= "+sp.calculate(3, 5));

	}

	@Override
	public void sendCall() {
		System.out.println("스마트폰 벨~~~~");
		
	}

	@Override
	public void receiveCall() {
		System.out.println("스마트폰 전화가 왔습니다.");
		
	}

}
