package day13;
import javax.swing.*;
public class MyFrame2 extends JFrame{
	
	//생성자.....
	public MyFrame2() {
		this.setTitle("나만의 프레임 생성");
		setSize(500,500);
		setVisible(true);
	}

	public static void main(String[] args) {
		// 1. 컨테이너 -JFrame 객체 생성
		MyFrame2 mf2 = new MyFrame2();
		//mf2.setSize(300,300);
		//mf2.setTitle("300X300 사이즈의 프레임");
		//mf2.setVisible(true);
		
		//2. 컴포먼트 생성 - JButton 객체 2개 생성
		JButton jbtn1 = new JButton("확인");
		JButton jbtn2 = new JButton();
		jbtn2.setText("취소");
		
		//3. 컨테이너에 컴포넌트 2개 버튼 부착(add)
		mf2.add(jbtn1);
		mf2.add(jbtn2);
		
		//3-1. 판넬 컨테이너 생성
		JPanel jp = new JPanel();
		jp.add(jbtn1);
		jp.add(jbtn2);
		
		//3-2. 프레임 컨테이너에 판넬 부착하기
		mf2.add(jp);
		
		//4. 컨테이너 닫기 동작 추가
		mf2.setDefaultCloseOperation(0);
		//jf.pack();

	}

}
