package day14;

import java.awt.Container;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class MouseListenerEx extends JFrame {

    JLabel lb;

    public MouseListenerEx() {
        Container con = getContentPane();

        // 직접 위치 지정하려면 null 레이아웃 사용
        con.setLayout(null);

        lb = new JLabel("hello");
        lb.setSize(50, 20);
        lb.setLocation(30, 30);
        con.add(lb);

        con.addMouseListener(new MyMouseListener());

        setSize(400, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new MouseListenerEx();
    }

    // 내부 클래스
    class MyMouseListener implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {
            int x = e.getX();
            int y = e.getY();

            lb.setLocation(x, y);
        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    }
}