package day14;

import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;

public class MouseListenerEx2 extends JFrame {

    JLabel lb;

    public MouseListenerEx2() {
        Container con = getContentPane();

        con.setLayout(null);

        lb = new JLabel("hello");
        lb.setSize(250, 20);
        lb.setLocation(30, 30);
        con.add(lb);

        con.addMouseMotionListener(new MyMouseListener());

        setSize(400, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new MouseListenerEx2();
    }

    class MyMouseListener extends MouseAdapter {

        @Override
        public void mouseDragged(MouseEvent e) {
            lb.setText("MouseDragged (" + e.getX() + ", " + e.getY() + ")");
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            lb.setText("MouseMoved (" + e.getX() + ", " + e.getY() + ")");
        }
    }
}