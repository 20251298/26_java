package day14;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MyJFrame extends JFrame {

    // 생성자
    public MyJFrame() {
        this.setTitle("나만의 프레임");

        Container con = getContentPane();
        con.setLayout(new FlowLayout());

        JButton btn = new JButton("소개");
        JTextField jf = new JTextField(20);
        JButton btn2 = new JButton("확인");
        con.add(btn2);
  
        con.add(btn);
        con.add(jf);

        btn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Object obj = e.getSource();

                if (obj == btn) {
                    System.out.println("소개 버튼 클릭");
                    System.out.println(jf.getText());
                }
            }
        });
        
        btn2.addActionListener(new ActionListener() {
         
         @Override
         public void actionPerformed(ActionEvent e) {
            
            System.out.println(jf.getText());
            //텍스트필드 초기화
            jf.setText("");
         }
      });

        setSize(300, 200);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new MyJFrame();
    }
}